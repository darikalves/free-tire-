<?
header('Location: id=1.php');
?>
